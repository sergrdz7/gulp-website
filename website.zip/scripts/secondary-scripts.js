var max = 12;

for(var i = 0; i < max; i++){
  console.log(i);
}
